package com.example.studiekoll;

public class course {
    String title;
    Integer hours;

    public course(String title, Integer hours){
        this.title=title;
        this.hours=hours;
    }

    public String getTitle() {
        return title;
    }

    public Integer getHours() {
        return hours;
    }
}
